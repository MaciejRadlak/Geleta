﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class uczen
    {
        public string pesel {  get; set; }
        public string haslo { get; set; }

    }


    internal static class uczen_info
    {
        public static uczen uczen_main_info = new uczen();
    }
}
