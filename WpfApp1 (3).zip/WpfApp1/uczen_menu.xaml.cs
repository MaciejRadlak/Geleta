﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Serialization;


namespace WpfApp1
{
    /// <summary>
    /// Logika interakcji dla klasy uczen_menu.xaml
    /// </summary>
    public partial class uczen_menu : Window
    {
        public uczen_menu()
        {
            InitializeComponent();
            using (SqlConnection conn = new SqlConnection(@"Data Source=192.168.175.85;Initial Catalog=szkola;User ID=admin2;Password=321;Connect Timeout=30"))
            {
                string haslo = uczen_info.uczen_main_info.haslo;
                string pesel = uczen_info.uczen_main_info.pesel;
                conn.Open();
                string query = "SELECT * FROM dbo.uczen INNER JOIN dbo.klasa ON dbo.uczen.klasa_id=dbo.klasa.id WHERE PESEL=" + pesel.ToString();
                SqlCommand cmd = conn.CreateCommand();
                cmd.CommandText = query;

                SqlDataReader reader = cmd.ExecuteReader();
                reader.Read();

                string j = (string)reader["imie"];
                _imie.Content = "imie: "+ j;
                string y = (string)reader["nazwisko"];
                _nazwisko.Content = "nazwisko: " + y;
                _pesel.Content = "PESEL: " + pesel;
                int x = (System.Int32)reader["wychowawca_id"];
                string szynka = (string)reader["klasa_id"];
                _klasa.Content = "Klasa: " + szynka;
                int p = (System.Int32)reader["punkty"];
                _punkty.Content = "punkty: " + p;
                reader.Close();
                string query2 = "SELECT nazwisko FROM dbo.nauczyciel WHERE PESEL=" + x.ToString();
                SqlCommand cmd2 = conn.CreateCommand();
                cmd2.CommandText = query2;

                SqlDataReader reader2 = cmd2.ExecuteReader();
                reader2.Read();
                string nazwwych = (string)reader2["nazwisko"];
                _wychowawca.Content = "wychowawca: "+ nazwwych;
                reader2.Close();

                string query3 = "SELECT AVG(ocena) FROM dbo.ocena WHERE id_ucznia=" + pesel.ToString();
                SqlCommand cmd3 = conn.CreateCommand();
                cmd3.CommandText = query3;
                SqlDataReader reader3 = cmd3.ExecuteReader();
                reader3.Read();
                int sr = (System.Int32)reader3[0];
                _srednia.Content = sr;
                reader3.Close();
                string query4 ="SELECT nazwa, ocena FROM dbo.ocena " +
                "INNER JOIN dbo.przedmiot ON dbo.ocena.id_przedmiotu = dbo.przedmiot.id " +
                "WHERE id_ucznia = @pesel " +
                "ORDER BY nazwa, ocena DESC";

                SqlCommand cmd4 = new SqlCommand(query4, conn);
                cmd4.Parameters.AddWithValue("@pesel", pesel);

                SqlDataReader reader4 = cmd4.ExecuteReader();

                string aktualnyPrzedmiot = "";
                string lista = "";
                int a = 0;
                while (reader4.Read())
                {
                    if (a == 0)
                    {
                        aktualnyPrzedmiot = reader4["nazwa"].ToString();
                        a += 1;
                    }
                    string nazwa = reader4["nazwa"].ToString();
                    string ocena = reader4["ocena"].ToString();
                    if (nazwa != aktualnyPrzedmiot)
                    {
                        _list.Items.Add(nazwa);
                        _list.Items.Add(lista);
                        aktualnyPrzedmiot = nazwa;
                        lista = "";
                        lista += ocena + "   ";
                    }
                    else
                    {
                        lista += ocena + "   ";
                    }

                }

            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow u = new MainWindow();
            u.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
